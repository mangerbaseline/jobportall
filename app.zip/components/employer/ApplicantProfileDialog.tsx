import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Mail, Clock, ExternalLink, FileText, Loader2 } from "lucide-react";

interface ApplicantProfileDialogProps {
  children: React.ReactNode;
  applicationId: string;
  basicData: {
    name: string;
    email: string;
    createdAt: string;
    resumeUrl: string;
  };
}

export default function ApplicantProfileDialog({
  children,
  applicationId,
  basicData,
}: ApplicantProfileDialogProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [fullData, setFullData] = useState<any>(null);

  const handleOpenChange = async (isOpen: boolean) => {
    setOpen(isOpen);
    if (isOpen && !fullData && !loading) {
      try {
        setLoading(true);
        const res = await fetch(`/api/application/${applicationId}`);
        if (!res.ok) throw new Error("Failed to fetch application details");
        const body = await res.json();
        if (body.success) {
          setFullData(body.application);
        }
      } catch (err) {
        console.error("Error fetching applicant details:", err);
      } finally {
        setLoading(false);
      }
    }
  };

  const professional = fullData?.user?.professional;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="bg-slate-900 border-white/10 text-white max-w-2xl max-h-[85vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">Applicant Profile</DialogTitle>
          <DialogDescription className="text-slate-400">
            Applied on {new Date(basicData.createdAt).toLocaleDateString()}
          </DialogDescription>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Basic Info */}
          <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-2xl font-bold text-white shadow-lg shrink-0">
              {basicData.name.charAt(0).toUpperCase()}
            </div>
            <div className="space-y-1">
              <h4 className="text-lg font-semibold">{basicData.name}</h4>
              <p className="text-sm text-slate-400 flex items-center gap-2">
                <Mail className="w-4 h-4" /> {basicData.email}
              </p>
            </div>
          </div>

          {loading ? (
            <div className="py-8 flex flex-col items-center justify-center gap-2">
              <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
              <p className="text-sm text-slate-400 font-medium animate-pulse">Loading professional details...</p>
            </div>
          ) : (
            <>
              {/* Professional Details */}
              {professional ? (
                <div className="space-y-4 animate-in fade-in zoom-in-95 duration-500">
                  <h4 className="text-lg font-semibold border-b border-white/10 pb-2">
                    Professional Details
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {professional.title && (
                      <div className="space-y-1">
                        <span className="text-xs text-slate-400 uppercase tracking-wider">
                          Current Title
                        </span>
                        <p className="font-medium">
                          {professional.title}
                        </p>
                      </div>
                    )}
                    {professional.company && (
                      <div className="space-y-1">
                        <span className="text-xs text-slate-400 uppercase tracking-wider">
                          Current Company
                        </span>
                        <p className="font-medium">
                          {professional.company}
                        </p>
                      </div>
                    )}
                    {professional.experience !== null &&
                      professional.experience !== undefined && (
                        <div className="space-y-1">
                          <span className="text-xs text-slate-400 uppercase tracking-wider">
                            Experience
                          </span>
                          <p className="font-medium">
                            {professional.experience} years
                          </p>
                        </div>
                      )}
                  </div>

                  {professional.skills && (
                    <div className="space-y-2 pt-2">
                      <span className="text-xs text-slate-400 uppercase tracking-wider">
                        Skills
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {professional.skills
                          .split(",")
                          .map((skill: string, i: number) => (
                            <span
                              key={i}
                              className="px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-full text-xs border border-indigo-500/20"
                            >
                              {skill.trim()}
                            </span>
                          ))}
                      </div>
                    </div>
                  )}

                  {professional.education && (
                    <div className="space-y-1 pt-2">
                      <span className="text-xs text-slate-400 uppercase tracking-wider">
                        Education
                      </span>
                      <p className="text-sm bg-white/5 p-3 rounded-lg border border-white/5">
                        {professional.education}
                      </p>
                    </div>
                  )}

                  {/* Links */}
                  {(professional.linkedin ||
                    professional.github ||
                    professional.portfolio) && (
                    <div className="space-y-2 pt-2">
                      <span className="text-xs text-slate-400 uppercase tracking-wider">
                        Links
                      </span>
                      <div className="flex flex-wrap gap-3">
                        {professional.linkedin && (
                          <a
                            href={professional.linkedin}
                            target="_blank"
                            rel="noreferrer"
                            className="text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />{" "}
                            LinkedIn
                          </a>
                        )}
                        {professional.github && (
                          <a
                            href={professional.github}
                            target="_blank"
                            rel="noreferrer"
                            className="text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />{" "}
                            GitHub
                          </a>
                        )}
                        {professional.portfolio && (
                          <a
                            href={professional.portfolio}
                            target="_blank"
                            rel="noreferrer"
                            className="text-sm text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />{" "}
                            Portfolio
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center text-slate-400">
                  <p>
                    No professional details provided by the applicant.
                  </p>
                </div>
              )}

              {/* Resume Button */}
              <div className="pt-4 border-t border-white/10 flex justify-end animate-in fade-in duration-500">
                <a
                  href={fullData?.resumeUrl || basicData.resumeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium transition-all shadow-lg shadow-indigo-600/20"
                >
                  <FileText className="w-4 h-4" />
                  View Full Resume
                  <ExternalLink className="w-4 h-4 ml-1 opacity-70" />
                </a>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
