import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { CounterState } from '@/types'

const initialState: CounterState = { value: 0 }

export const counterSlice = createSlice({
    name: 'counter',
    initialState,
    reducers: {
        increment: (state) => { state.value += 1 },
        decrement: (state) => { state.value -= 1 },
        setValue: (state, action: PayloadAction<number>) => {
            state.value = action.payload
        },
    },
})

export const { increment, decrement, setValue } = counterSlice.actions
export default counterSlice.reducer

